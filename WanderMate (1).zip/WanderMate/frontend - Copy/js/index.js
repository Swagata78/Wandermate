// ===== Scroll animation for cards, destinations, reviews =====
document.addEventListener("scroll", () => {
  document.querySelectorAll(".card, .dest, .review").forEach((el) => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 50) {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    }
  });
});

// Initial hidden state
document.querySelectorAll(".card, .dest, .review").forEach((el) => {
  el.style.opacity = "0";
  el.style.transform = "translateY(30px)";
  el.style.transition = "all 0.6s ease-out";
});

// ===== Login Button Redirect =====
document.querySelector(".login-btn").addEventListener("click", () => {
  window.location.href = "login.html";
});

// ===== CTA Button Redirect =====
document.querySelector(".cta-btn").addEventListener("click", () => {
  window.location.href = "registor.html";
});

// ===== Newsletter Subscribe =====
document.querySelector(".newsletter button").addEventListener("click", () => {
  const emailInput = document.querySelector(".newsletter input").value.trim();
  if (emailInput) {
    alert(`🎉 Thanks for subscribing, ${emailInput}!`);
    document.querySelector(".newsletter input").value = "";
  } else {
    alert("⚠️ Please enter a valid email address.");
  }
});

// ===== Destination Data (full list) =====
const destinationsData = [
  { name: "Japan", image: "../image/tokyo.png" },
  { name: "France", image: "../image/paris.png" },
  { name: "Australia", image: "../image/australia.png" },
  { name: "Italy", image: "../image/italy.png" },
  { name: "Brazil", image: "../image/brazil.png" },
  { name: "China", image: "../image/china.png" },
  { name: "Korea", image: "../image/sole.png" },
  { name: "Spain", image: "../image/spain.png" },
  { name: "India", image: "../image/india.png" },
  { name: "Indonaisa", image: "../image/indo.png" },
  { name: "Thiland", image: "../image/thil.png" },
  { name: "Switzerland", image: "../image/swit.png" },
  { name: "Canada", image: "../image/canada.png" },
  { name: "Egypt", image: "../image/egypt.png" },
  { name: "Maldives", image: "../image/mald.png" },
  { name: "Hong Kong", image: "../image/hong.png" },
  { name: "Finland", image: "../image/fin.png" },
  { name: "Philippines", image: "../image/phill.png" }
];

// ===== Search Bar Functionality with Explore Option =====
document.querySelector(".search-bar button").addEventListener("click", () => {
  const query = document.querySelector(".search-bar input").value.toLowerCase().trim();

  if (!query) {
    alert("⚠️ Please enter a destination to search.");
    return;
  }

  // 🔍 Search in the destination array (more reliable than DOM text)
  const result = destinationsData.find(dest =>
    dest.name.toLowerCase().includes(query)
  );

  if (result) {
    // ✅ Ask user if they want to explore
    const confirmExplore = confirm(`Do you want to explore ${result.name}?`);
    if (confirmExplore) {
      // Store destination name for explore.html
      localStorage.setItem("selectedDestination", result.name);
      window.location.href = "explore.html";
    }
  } else {
    alert("❌ No destinations found.");
  }
});
